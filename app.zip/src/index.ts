import express from "express";
import dotenv from "dotenv";
import betRoutes from "./routes/betRoutes";
import logger from "./config/logger";

dotenv.config();

const app = express();
app.use(express.json());

// Add the health check route
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "UP",
    message: "Application is running smoothly!",
    timestamp: new Date().toISOString(),
  });
});

// Mount other routes
app.use("/api", betRoutes);

const PORT = process.env.PORT || 8080;
const server = app.listen(PORT, () => {
  logger.info(`Server running on http://localhost:${PORT}`);
});

// Export the app and server for testing
export { app, server };